// Tic-Tac-Toe game logic
const cells = Array.from(document.querySelectorAll('.cell'));
const statusDiv = document.getElementById('status');
let currentPlayerSpan = document.getElementById('current-player');
const menu = document.getElementById('menu');
const gameUI = document.getElementById('gameUI');

let gameMode = 2; // 1 = vs CPU, 2 = PvP
let gameActive = false;
let currentPlayer = 'X';
let gameState = Array(9).fill('');
let score = { X: 0, O: 0 };
const MATCH_TARGET = 5;

// Players for 1-player mode
let humanPlayer = 'X';
let cpuPlayer = 'O';

const scoreXEl = document.getElementById('scoreX');
const scoreOEl = document.getElementById('scoreO');
const matchMsgEl = document.getElementById('matchMsg');
const resetMatchBtn = document.getElementById('resetMatchBtn');
const labelX = document.getElementById('labelX');
const labelO = document.getElementById('labelO');
const themeToggleBtn = document.getElementById('themeToggle');

const winConditions = [
  [0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]
];

function startGame(mode, humanSymbol) {
  gameMode = mode;
  // if humanSymbol provided, this is 1-player start after choice
  if (gameMode === 1 && humanSymbol) {
    humanPlayer = humanSymbol;
    cpuPlayer = humanPlayer === 'X' ? 'O' : 'X';
    // update labels to reflect who is who
    if (labelX && labelO) {
      labelX.innerText = (humanPlayer === 'X') ? 'You (X)' : 'CPU (X)';
      labelO.innerText = (humanPlayer === 'O') ? 'You (O)' : 'CPU (O)';
    }
    // hide symbol chooser
    const sym = document.getElementById('symbolMenu');
    if (sym) sym.classList.add('hidden');
  } else {
    // PvP labels
    if (labelX && labelO) {
      labelX.innerText = 'Player X';
      labelO.innerText = 'Player O';
    }
  }

  menu.classList.add('hidden');
  gameUI.classList.remove('hidden');
  updateScoreboard();
  matchMsgEl && (matchMsgEl.innerText = '');
  restartGame();

  // If CPU is X, let CPU play first
  if (gameMode === 1 && cpuPlayer === 'X') {
    gameActive = false;
    setTimeout(() => { computerMove(); }, 600);
  }
}

function backToMenu() {
  menu.classList.remove('hidden');
  gameUI.classList.add('hidden');
  gameActive = false;
}

function restartGame() {
  gameState = Array(9).fill('');
  currentPlayer = 'X';
  gameActive = true;
  statusDiv.innerHTML = `Player <span id="current-player">X</span>'s Turn`;
  currentPlayerSpan = document.getElementById('current-player');
  cells.forEach(c => { c.innerText = ''; c.className = 'cell'; });
}

function updateScoreboard() {
  if (scoreXEl) scoreXEl.innerText = score.X;
  if (scoreOEl) scoreOEl.innerText = score.O;
}

function resetMatch() {
  score = { X: 0, O: 0 };
  updateScoreboard();
  matchMsgEl && (matchMsgEl.innerText = '');
  restartGame();
}

function handleCellClick(e) {
  if (!gameActive) return;
  const idx = parseInt(e.target.getAttribute('data-index'), 10);
  if (gameState[idx] !== '') return;
  // If vs CPU only allow human to click on human's turn
  if (gameMode === 1 && currentPlayer !== humanPlayer) return;

  playMove(idx, currentPlayer);

  if (gameMode === 1 && gameActive && currentPlayer === cpuPlayer) {
    // after human move (which switched currentPlayer), trigger CPU
    gameActive = false;
    setTimeout(() => { computerMove(); }, 450);
  }
}

function playMove(idx, player) {
  gameState[idx] = player;
  const cell = cells[idx];
  cell.innerText = player;
  cell.classList.add(player.toLowerCase());
  cell.classList.add('animate');
  checkResult(player);
  if (gameActive) {
    currentPlayer = (player === 'X') ? 'O' : 'X';
    if (!currentPlayerSpan || !document.body.contains(currentPlayerSpan)) {
      currentPlayerSpan = document.getElementById('current-player');
    }
    if (currentPlayerSpan) currentPlayerSpan.innerText = currentPlayer;
  }
}

function computerMove() {
  const empty = gameState.map((v,i)=> v===''?i:null).filter(v=>v!==null);
  if (empty.length === 0) return;
  // Try to win, then block, else take center, else random
  let move = findWinningMove(cpuPlayer) ?? findWinningMove(humanPlayer) ?? (gameState[4]===''?4:null) ?? empty[Math.floor(Math.random()*empty.length)];
  gameActive = true;
  playMove(move, cpuPlayer);
}

function findWinningMove(player) {
  for (let cond of winConditions) {
    const [a,b,c] = cond;
    const vals = [gameState[a], gameState[b], gameState[c]];
    const count = vals.filter(v=>v===player).length;
    const emptyCount = vals.filter(v=>v==='').length;
    if (count===2 && emptyCount===1) {
      const emptyIndex = cond[vals.indexOf('')];
      return emptyIndex;
    }
  }
  return null;
}

function checkResult(lastPlayer) {
  let won = false;
  for (let cond of winConditions) {
    if (gameState[cond[0]] !== '' && gameState[cond[0]] === gameState[cond[1]] && gameState[cond[0]] === gameState[cond[2]]) {
      won = true; break;
    }
  }
  if (won) {
    // increment score for the round winner
    score[lastPlayer]++;
    updateScoreboard();

    // If someone reached match target, declare match winner
    if (score[lastPlayer] >= MATCH_TARGET) {
      statusDiv.innerText = `Match Winner: Player ${lastPlayer}!`;
      matchMsgEl && (matchMsgEl.innerText = `Player ${lastPlayer} reached ${MATCH_TARGET} points`);
      gameActive = false;
      return;
    }

    // Round winner, prepare next round
    statusDiv.innerText = `Player ${lastPlayer} Wins this Round!`;
    gameActive = false;
    setTimeout(() => { if (matchMsgEl) matchMsgEl.innerText = ''; restartGame(); }, 1000);
    return;
  }
  if (!gameState.includes('')) {
    statusDiv.innerText = 'Draw!';
    gameActive = false;
    setTimeout(() => { restartGame(); }, 900);
    return;
  }
}

cells.forEach(cell => cell.addEventListener('click', handleCellClick));
const restartBtn = document.getElementById('restartBtn');
if (restartBtn) restartBtn.addEventListener('click', restartGame);
if (resetMatchBtn) resetMatchBtn.addEventListener('click', resetMatch);

// Symbol chooser helpers
function showSymbolChoice() {
  const sym = document.getElementById('symbolMenu');
  if (sym) sym.classList.remove('hidden');
  // hide main menu while choosing
  menu.classList.add('hidden');
}

function closeSymbolChoice() {
  const sym = document.getElementById('symbolMenu');
  if (sym) sym.classList.add('hidden');
  // show main menu again
  menu.classList.remove('hidden');
}

// Theme toggle: persist in localStorage
function applySavedTheme() {
  const t = localStorage.getItem('theme');
  if (t === 'light') {
    document.body.classList.add('light-theme');
  } else {
    document.body.classList.remove('light-theme');
  }
  updateThemeButton();
}

function toggleTheme() {
  document.body.classList.toggle('light-theme');
  const isLight = document.body.classList.contains('light-theme');
  localStorage.setItem('theme', isLight ? 'light' : 'dark');
  updateThemeButton();
}

function updateThemeButton() {
  if (!themeToggleBtn) return;
  const isLight = document.body.classList.contains('light-theme');
  themeToggleBtn.innerText = isLight ? '🌙' : '☀️';
}

if (themeToggleBtn) {
  themeToggleBtn.addEventListener('click', toggleTheme);
}

// Apply saved theme on load
applySavedTheme();